﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using image_designer;

namespace MaxssauLibraries
{
    struct RAW_ConversionStages
    {
        public bool LinearizeData;
        public bool WhiteBalanceCorrection;
        public bool ClipImageData;
        public bool Demosaic;
        public bool ColorTransform;
        public bool GammaCorrection;
        public bool BlackSubstract;
    }

    enum RAW_Converter_Output_Type
    {
        RAW_Output_RGB=0,
        RAW_Output_LAB=1,
        RAW_Output_XYZ=2,
        RAW_Output_HSV=3
    }

    struct RAW_ConversionSetup
    {
        public bool HasDCPData;
    }

    struct InputRAWImage
    {
        public RGB_Pixel[,]                     Image_Input_RAW_RGB;
        public RGB_MinMaxValues                 Image_Input_MinMaxLevels;
        public int ImageWidth;
        public int ImageHeight;
    }

    struct ImagePack
    {
        public RGB_Pixel[,] Image_RGB;
        public XYZ_Pixel[,] Image_XYZ;
        public LAB_Pixel[,] Image_LAB;
        public HSV_Pixel[,] Image_HSV;
        public RGB_MinMaxValues RGB_MinMax;
        public XYZ_MinMaxValues XYZ_MinMax;
        public HSV_MinMaxValues HSV_MinMax;
        public LAB_MinMaxValues LAB_MinMax;
    }

    struct WhiteBalanceRGBAvg
    {
        private double R_summ;
        private double G_summ;
        private double B_summ;

        private double summ;

        private double R_coeff;
        private double G_coeff;
        private double B_coeff;

        public double GetRCoeff()
        {
            double max = GetMax();
            if (GetMax() != 0)
            {
                return R_coeff / GetMax();
            }
            else
            {
                return 1;
            }
        }

        public double GetGCoeff()
        {
            double max = GetMax();
            if (GetMax() != 0)
            {
                return G_coeff / GetMax();
            }
            else
            {
                return 1;
            }
        }

        public double GetBCoeff()
        {
            double max = GetMax();
            if (GetMax() != 0)
            {
                return B_coeff / GetMax();
            }
            else
            {
                return 1;
            }
        }

        private double GetMax()
        {
            return Math.Max(Math.Max(R_summ, G_summ), B_summ);
        }

        public void add(double R, double G, double B)
        {
            R_summ = R_summ + R;
            G_summ = G_summ + G;
            B_summ = B_summ + B;

            summ = summ + R + G + B;
        }

        public void clear()
        {
            R_summ = 0;
            G_summ = 0;
            B_summ = 0;
        }
    }

    internal class classRAWConverter
    {
        private classDCPXMLReader               DCP_data;

        public RAW_ConversionStages             ConversionStageSetup=new RAW_ConversionStages();
        public RAW_ConversionSetup              ConversionSetup=new RAW_ConversionSetup();

        public RAW_Converter_Output_Type        OutputType;

        private classLogger                     Logger;

        public InputRAWImage                    RawImage = new InputRAWImage();

        public ImagePack                        ImageOutput = new ImagePack();
        public ImagePack                        ImageTemp = new ImagePack();

        public WhiteBalanceRGBAvg               WB_rgb =new WhiteBalanceRGBAvg();

        private classColorConversion            ColorConverter=new classColorConversion();

        public  OperationStatus RAW_Process()
        {
            try
            {
                if (DCP_data.HasDCPData.HasColorMatrix1 == true)
                {

                    if (RawImage.Image_Input_RAW_RGB != null)
                    {
                        if (RawImage.Image_Input_RAW_RGB.Length > 0)
                        {
                            ImageTemp.Image_RGB = new RGB_Pixel[RawImage.ImageWidth, RawImage.ImageHeight];
                            ImageTemp.Image_XYZ = new XYZ_Pixel[RawImage.ImageWidth, RawImage.ImageHeight];

                            RGB_MinMaxValues BlackSubstractRGB_MinMax = new RGB_MinMaxValues();
                            RGB_MinMaxValues WBRGB_MinMax = new RGB_MinMaxValues();

                            BlackSubstractRGB_MinMax.reset();
                            WBRGB_MinMax.reset();

                            WB_rgb.clear();

                            for (int x = 0; x < RawImage.ImageWidth; x++)
                            {
                                for (int y = 0; y < RawImage.ImageHeight; y++)
                                {
                                    if (ConversionStageSetup.BlackSubstract == true)
                                    {
                                        ImageTemp.Image_RGB[x, y].R = RawImage.Image_Input_RAW_RGB[x, y].R - RawImage.Image_Input_MinMaxLevels.R.get_min();
                                        ImageTemp.Image_RGB[x, y].G = RawImage.Image_Input_RAW_RGB[x, y].G - RawImage.Image_Input_MinMaxLevels.G.get_min();
                                        ImageTemp.Image_RGB[x, y].B = RawImage.Image_Input_RAW_RGB[x, y].B - RawImage.Image_Input_MinMaxLevels.B.get_min();

                                        BlackSubstractRGB_MinMax.R.calc(ImageTemp.Image_RGB[x, y].R);
                                        BlackSubstractRGB_MinMax.G.calc(ImageTemp.Image_RGB[x, y].G);
                                        BlackSubstractRGB_MinMax.B.calc(ImageTemp.Image_RGB[x, y].B);
                                    }

                                    WB_rgb.add(ImageTemp.Image_RGB[x, y].R, ImageTemp.Image_RGB[x, y].G, ImageTemp.Image_RGB[x, y].B);
                                }
                            }

                            double coeff = Math.Min(BlackSubstractRGB_MinMax.R.get_max(), Math.Min(BlackSubstractRGB_MinMax.G.get_max(), BlackSubstractRGB_MinMax.B.get_max()));

                            double[] temp_rgb_in=new double[3];
                            double[] temp_rgb_out = new double[3];


                            for (int x = 0; x < RawImage.ImageWidth; x++)
                            {
                                for (int y = 0; y < RawImage.ImageHeight; y++)
                                {
                                    if (ConversionStageSetup.WhiteBalanceCorrection == true)
                                    {
                                        ImageTemp.Image_RGB[x, y].R = (ImageTemp.Image_RGB[x, y].R / coeff) / (WB_rgb.GetRCoeff());
                                        ImageTemp.Image_RGB[x, y].G = (ImageTemp.Image_RGB[x, y].G / coeff) / (WB_rgb.GetGCoeff());
                                        ImageTemp.Image_RGB[x, y].B = (ImageTemp.Image_RGB[x, y].B / coeff) / (WB_rgb.GetBCoeff());
                                    }

                                    // trunc data
                                    ImageTemp.Image_RGB[x, y].R = Math.Min(1, ImageTemp.Image_RGB[x, y].R);
                                    ImageTemp.Image_RGB[x, y].G = Math.Min(1, ImageTemp.Image_RGB[x, y].G);
                                    ImageTemp.Image_RGB[x, y].B = Math.Min(1, ImageTemp.Image_RGB[x, y].B);

                                    if(ConversionStageSetup.ColorTransform==true)
                                    {
                                        temp_rgb_in[0] = ImageTemp.Image_RGB[x, y].R;
                                        temp_rgb_in[1] = ImageTemp.Image_RGB[x, y].G;
                                        temp_rgb_in[2] = ImageTemp.Image_RGB[x, y].B;
                                        ColorConverter.MulMatrix3x3withM3(ref DCP_data.ColorMatrix1.coeff, ref temp_rgb_out, temp_rgb_in);
                                        ImageTemp.Image_XYZ[x, y].X = temp_rgb_out[0];
                                        ImageTemp.Image_XYZ[x, y].Y = temp_rgb_out[1];
                                        ImageTemp.Image_XYZ[x, y].Z = temp_rgb_out[2];
                                    }
                                }
                            }



                            return OperationStatus.STATUS_OK;
                        }
                        else
                        {
                            return OperationStatus.STATUS_FAIL;
                        }
                    }
                    else
                    {
                        return OperationStatus.STATUS_FAIL;
                    }
                }
                else
                {
                    return OperationStatus.STATUS_FAIL;
                }
            }
            catch (Exception ex)
            {
                if (Logger != null)
                {
                    Logger.add_to_log("RAW Converter: conversion", ex.Message);
                    if (ex.StackTrace != null)
                    {
                        Logger.add_to_log("RAW Converter: conversion", ex.StackTrace);
                    }
                }
                return OperationStatus.STATUS_FAIL;
            }
        }

        public OperationStatus LoadDCPData(string filename)
        {
            try
            {
                if (filename != null)
                {
                    if (filename != "")
                    {
                        DCP_data = new classDCPXMLReader(filename);
                        if (DCP_data.HasDCPData.HasColorMatrix1 == true)
                        {
                            ConversionSetup.HasDCPData = true;
                            return OperationStatus.STATUS_OK;
                        }
                        else
                        {
                            return OperationStatus.STATUS_FAIL;
                        }
                    }
                    else
                    {
                        return OperationStatus.STATUS_FAIL;
                    }
                }
                else
                {
                    return OperationStatus.STATUS_FAIL;
                }
            }
            catch (Exception ex)
            {
                if(Logger != null)
                {
                    Logger.add_to_log("RAW Converter: DCP Loader", ex.Message);
                    if(ex.StackTrace != null)
                    {
                        Logger.add_to_log("RAW Converter: DCP Loader", ex.StackTrace);
                    }
                }
                return OperationStatus.STATUS_FAIL;
            }
        }

        public classRAWConverter(ref classLogger logger)
        {
            Logger = logger;
        }

        
    }
}
