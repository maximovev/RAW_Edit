﻿using MaxssauLibraries;

classXMLCMReader reader;

Main();

void Main()
{

    reader = new classXMLCMReader("camera_cm.xml");

    Console.WriteLine("Hello, World!");
}

